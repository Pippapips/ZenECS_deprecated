﻿namespace ZenECS.Core.Messaging
{
    public interface IMessage
    {
    }
}
