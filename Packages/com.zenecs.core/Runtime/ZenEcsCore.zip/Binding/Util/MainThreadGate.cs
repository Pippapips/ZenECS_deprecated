namespace ZenECS.Core.Binding.Util
{
    public static class MainThreadGate
    {
        public static void Ensure()
        {
        }
    }
}