﻿#nullable enable
using System;

namespace ZenECS.Core.Infrastructure
{
    public interface IEcsLogger
    {
        void Info(string msg);
        void Warn(string msg);
        void Error(string msg);
    }
    
    /// <summary>
    /// Global policies for ZenECS write/validation handling and logging.
    /// 앱 시작 시점에 DeniedPolicy와 Logger를 설정하세요.
    /// </summary>
    public static class EcsRuntimeOptions
    {
        /// <summary>
        /// How to handle write-denied/validation-failed situations.
        /// </summary>
        public enum WriteFailurePolicy
        {
            Silent,
            Log,
            Throw,
        }

        /// <summary>
        /// 실패 처리 정책. 기본값은 Throw.
        /// </summary>
        public static WriteFailurePolicy WritePolicy = WriteFailurePolicy.Throw;

        /// <summary>
        /// 로깅 델리게이트. 기본 no-op (경고/오버헤드 최소화).
        /// </summary>
        public static IEcsLogger Log = NoOpLogger.Instance;
        
        public static void UseDevelopmentDefaults(IEcsLogger? logger  = null)
        {
            WritePolicy = WriteFailurePolicy.Throw;
            Log = logger ?? NoOpLogger.Instance; // 또는 Unity/Console 로거
        }

        public static void UseProductionDefaults()
        {
            WritePolicy = WriteFailurePolicy.Log;
            // Log는 앱이 설정
        }
        
        private sealed class NoOpLogger : IEcsLogger
        {
            public static readonly NoOpLogger Instance = new();
            public void Info(string msg) {}
            public void Warn(string msg) {}
            public void Error(string msg) {}
        }        
    }
}