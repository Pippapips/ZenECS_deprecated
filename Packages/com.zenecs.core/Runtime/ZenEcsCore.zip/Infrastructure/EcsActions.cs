﻿#nullable enable
using System;
using System.Runtime.CompilerServices;
using ZenECS.Core.Events;

namespace ZenECS.Core.Infrastructure
{
    /// <summary>모든 쓰기(Add/Replace/Remove)의 단일 관문(검증/권한/이벤트/지연반영)</summary>
    internal static class EcsActions
    {
        // ===== Policy / Logger ===========================================================
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private static bool HandleDenied(string reason)
        {
            switch (EcsRuntimeOptions.WritePolicy)
            {
                case EcsRuntimeOptions.WriteFailurePolicy.Throw:
                    throw new InvalidOperationException(reason);
                case EcsRuntimeOptions.WriteFailurePolicy.Log:
                    EcsRuntimeOptions.Log.Warn(reason);
                    return false;
                default: // Silent
                    return false;
            }            
        }

        public static bool PreferDeferredAdds = false; // 루프 중 구조적 변경 안전 기본값

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private static bool CanRead<T>(World w, Entity e) where T : struct
        {
            return w.EvaluateReadPermission(e, typeof(T));
        }
        
        // =========================================================================
        // Add
        // =========================================================================
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        internal static void Add<T>(World w, Entity e, in T value, World.CommandBuffer? cb = null) where T : struct
        {
            if (!w.EvaluateWritePermission(e, typeof(T)))
            {
                if (!HandleDenied($"[Denied] Add<{typeof(T).Name}> e={e.Id} reason=WritePermission"))
                    return;
            }
            
            bool valid = w.ValidateTyped(in value);
            if (!valid)
            {
                if (!HandleDenied($"[Denied] Add<{typeof(T).Name}> e={e.Id} reason=ValidateFailed value={value}"))
                    return;
            }
            else
            {
                if (!w.ValidateObject(value!))
                {
                    if (!HandleDenied($"[Denied] Add<{typeof(T).Name}> e={e.Id} reason=ValidateFailed(value-hook) value={value}"))
                        return;
                }
            }    
            
            if (w.HasComponentInternal<T>(e)) return;

            // CommandBuffer 우선: 넘겨받은 cb가 있으면 반드시 그 cb에 기록
            if (cb != null) { cb.Add(e, in value); return; }
            // cb가 없고 지연 선호이면 임시 cb 생성 후 스케줄
            if (PreferDeferredAdds)
            {
                var tmp = w.BeginWrite();
                tmp.Add(e, in value);
                w.Schedule(tmp);
                return;
            }            

            ref var r = ref w.RefComponentInternal<T>(e);
            r = value;
            ComponentEvents.RaiseAdded(w, e, typeof(T));
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        internal static void AddOrReplace<T>(World w, Entity e, in T value, World.CommandBuffer? cb = null) where T : struct
        {
            if (Has<T>(w, e)) { Replace(w, e, in value); return; }
            Add(w, e, in value, cb);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        internal static T GetOrAdd<T>(World w, Entity e, in T initial, World.CommandBuffer? cb = null) where T : struct
        {
            if (w.TryGetComponentInternal<T>(e, out var v)) return v;
            Add(w, e, in initial, cb);
            return initial;
        }

        // =========================================================================
        // Replace
        // =========================================================================
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        internal static void Replace<T>(World w, Entity e, in T value) where T : struct
        {
            if (!w.EvaluateWritePermission(e, typeof(T)))
            {
                if (!HandleDenied($"[Denied] Replace<{typeof(T).Name}> e={e.Id} reason=WritePermission"))
                    return;
            }            
            
            bool valid = w.ValidateTyped(in value);
            if (!valid)            
            {
                if (!HandleDenied($"[Denied] Replace<{typeof(T).Name}> e={e.Id} reason=ValidateFailed value={value}"))
                    return;                
            }            
            else
            {
                if (!w.ValidateObject(value!))
                {
                    if (!HandleDenied($"[Denied] Replace<{typeof(T).Name}> e={e.Id} reason=ValidateFailed(value-hook) value={value}"))
                        return;
                }
            }            
            
            ref var r = ref w.RefComponentInternal<T>(e);
            r = value;
            ComponentEvents.RaiseChanged(w, e, typeof(T));
        }

        // =========================================================================
        // Remove
        // =========================================================================
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        internal static void Remove<T>(World w, Entity e) where T : struct
        {
            if (!w.EvaluateWritePermission(e, typeof(T)))
            {
                if (!HandleDenied($"[Denied] Remove<{typeof(T).Name}> e={e.Id} reason=WritePermission"))
                    return;
            }
            
            if (w.RemoveComponentInternal<T>(e))
                ComponentEvents.RaiseRemoved(w, e, typeof(T));
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        internal static void Toggle<T>(World w, Entity e, bool on) where T : struct
        {
            if (on) AddOrReplace(w, e, default(T));
            else Remove<T>(w, e);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        internal static bool Has<T>(World w, Entity e) where T : struct
        {
            // 읽기는 쓰기 퍼미션과 분리 (Has는 항상 읽기 가능해야 한다)
            return w.HasComponentInternal<T>(e);
        }
        
        internal static ref readonly T Read<T>(World w, Entity e) where T : struct
        {
            return ref w.RefComponentInternal<T>(e);
        }
    }
}