﻿#nullable enable
using System;
using ZenECS.Core;
using ZenECS.Core.Messaging;
using ZenECS.Core.Events;
using ZenECS.Core.Systems;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

namespace ZenECS.Core.Hosting
{
    public sealed class EcsHost : IEcsHost
    {
        private readonly object _gate = new();

        private World? _world;
        private MessageBus? _bus;
        private SystemRunner? _runner;
        private float _accumulator;
        public World World => _world ?? throw new InvalidOperationException("ECS host not started.");
        public MessageBus Bus => _bus ?? throw new InvalidOperationException("ECS host not started.");

        public bool IsRunning { get; private set; }

        public void Start(WorldConfig config, Action<World, MessageBus>? configure = null)
        {
            lock (_gate)
            {
                if (IsRunning) return;
                _world = new World(config);
                _bus = new MessageBus();
                configure?.Invoke(_world, _bus);
                IsRunning = true;
            }
        }

        // ---- Runner 관리 -----------------------------------------------------
        /// <summary>Runner 인스턴스를 초기화하고 시스템들을 등록/초기화합니다.</summary>
        public void InitializeSystems(IEnumerable<ISystem> systems,
            SystemRunnerOptions? options = null,
            Action<string>? log = null)
        {
            lock (_gate)
            {
                if (!IsRunning) throw new InvalidOperationException("Host not started.");
                if (_runner != null) return;
                _runner = new SystemRunner(World, null, new List<ISystem>(systems), options ?? new SystemRunnerOptions(), log);
                _runner.InitializeSystems();
            }
        }

        /// <summary>Runner 인스턴스를 외부에서 가져옵니다.</summary>
        public SystemRunner Runner
            => _runner ?? throw new InvalidOperationException("Runner not initialized. Call InitializeSystems(...) first.");

        /// <summary>프레임 시작(가변 스텝). World.DeltaTime이 설정됩니다.</summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public void BeginFrame(float dt)
        {
            if (_runner is null) throw new InvalidOperationException("Runner not initialized.");
            _runner.BeginFrame(dt);
        }
        
        /// <summary>고정 스텝 1회. World.FixedDeltaTime이 설정됩니다.</summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public void FixedStep(float fixedDelta)
        {
            if (_runner is null) throw new InvalidOperationException("Runner not initialized.");
            _runner.FixedStep(fixedDelta);
        }
        
        /// <summary>프레젠테이션(읽기 전용) 단계. 보간 계수 alpha 전달.</summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public void LateFrame(float alpha)
        {
            if (_runner is null) throw new InvalidOperationException("Runner not initialized.");
            _runner.LateFrame(alpha);
        }
        
        /// <summary>
        /// dt를 누적하여 fixedDelta로 가능한 만큼 서브스텝을 수행하고, alpha(0..1)를 계산합니다.
        /// 외부 루프에서 BeginFrame/FixedStep/LateFrame 호출을 간편화하기 위한 유틸입니다.
        /// </summary>
        public int Pump(float dt, float fixedDelta, int maxSubSteps, out float alpha)
        {
            if (_runner is null) throw new InvalidOperationException("Runner not initialized.");
            BeginFrame(dt);
            _accumulator += dt;
            int sub = 0;
            while (_accumulator >= fixedDelta && sub < maxSubSteps)
            {
                FixedStep(fixedDelta);
                _accumulator -= fixedDelta;
                sub++;
            }
            alpha = fixedDelta > 0f ? Math.Clamp(_accumulator / fixedDelta, 0f, 1f) : 1f;
            return sub;
        }
        
        /// <summary>Runner 시스템 종료 훅(필요 시 수동 호출). Shutdown에서 자동 호출됩니다.</summary>
        public void ShutdownSystems()
        {
            lock (_gate)
            {
                _runner?.ShutdownSystems();
                _runner = null;
                _accumulator = 0f;
            }
        }
        
        public void Shutdown()
        {
            lock (_gate)
            {
                if (!IsRunning) return;
                
                // Runner 먼저 정리(시스템 종료 및 누적값 초기화)
                _runner?.ShutdownSystems();
                _runner = null;
                _accumulator = 0f;
                
                _bus?.Clear();
                ComponentEvents.Reset();
                EntityEvents.Reset();
                _world?.Reset(false);
                _bus = null;
                _world = null;
                IsRunning = false;
            }
        }

        public void Dispose() => Shutdown();
    }
}