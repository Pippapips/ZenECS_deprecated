﻿#nullable enable
using ZenECS.Core;
using ZenECS.Core.Messaging;
using System;
using System.Collections.Generic;
using ZenECS.Core.Systems;

namespace ZenECS.Core.Hosting
{
    public interface IEcsHost : IDisposable
    {
        World World { get; }
        MessageBus Bus { get; }
        bool IsRunning { get; }

        void Start(WorldConfig config, Action<World, MessageBus>? configure = null);
        void Shutdown();

        // ---- Runner lifecycle / forwarding ----
        void InitializeSystems(IEnumerable<ISystem> systems,
            SystemRunnerOptions? options = null,
            Action<string>? log = null);
        SystemRunner Runner { get; }
        void BeginFrame(float dt);
        void FixedStep(float fixedDelta);
        void LateFrame(float alpha);
        int Pump(float dt, float fixedDelta, int maxSubSteps, out float alpha);
    }
}