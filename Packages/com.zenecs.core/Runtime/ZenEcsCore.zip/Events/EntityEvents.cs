﻿#nullable enable
using System;
using System.Runtime.CompilerServices;

namespace ZenECS.Core.Events
{
    internal static class EntityEvents
    {
        internal static event Action<World, Entity>? EntityCreated;
        internal static event Action<World, Entity>? EntityDestroyRequested;
        internal static event Action<World, Entity>? EntityDestroyed;

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        internal static void RaiseCreated(World w, Entity e) => EntityCreated?.Invoke(w, e);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        internal static void RaiseDestroyRequested(World w, Entity e) => EntityDestroyRequested?.Invoke(w, e);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        internal static void RaiseDestroyed(World w, Entity e) => EntityDestroyed?.Invoke(w, e);
        
        /// <summary>
        /// 에디터 도메인 리로드/런타임 재시작 시 누수 방지를 위한 일괄 해제.
        /// </summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        internal static void Reset()
        {
            EntityCreated = null;
            EntityDestroyRequested = null;
            EntityDestroyed = null;
        }
    }
}