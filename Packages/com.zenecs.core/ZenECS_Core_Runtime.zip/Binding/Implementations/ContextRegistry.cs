﻿#nullable enable
using System;
using System.Collections.Generic;

namespace ZenECS.Core.Binding
{
    /// <summary>World → EntityId → (ContextType → Instance)</summary>
    public sealed class ContextRegistry : IContextRegistry
    {
        private readonly Dictionary<World, Dictionary<int, Dictionary<Type, IContext>>> _byWorld
            = new(ReferenceEqualityComparer<World>.Instance);

        private World _world;

        public ContextRegistry(World world)
        {
            _world = world;
        }

        private Dictionary<int, Dictionary<Type, IContext>> BagFor(World w)
        {
            if (w == null) throw new ArgumentNullException(nameof(w));
            if (!_byWorld.TryGetValue(w, out var perEntity))
                _byWorld[w] = perEntity = new Dictionary<int, Dictionary<Type, IContext>>(1024);
            return perEntity;
        }

        private Dictionary<Type, IContext> BagFor(World w, Entity e)
        {
            var perEntity = BagFor(w);
            if (!perEntity.TryGetValue(e.Id, out var ctxs))
                perEntity[e.Id] = ctxs = new Dictionary<Type, IContext>(8);
            return ctxs;
        }

        public void Register<T>(World w, Entity e, T ctx) where T : class, IContext
        {
            if (w == null) throw new ArgumentNullException(nameof(w));
            if (ctx == null) throw new ArgumentNullException(nameof(ctx));
            BagFor(w, e)[typeof(T)] = ctx;
        }
        public void Register<T>(Entity e, T ctx) where T : class, IContext
            => Register(_world, e, ctx);

        // ✅ 추가: 런타임 타입으로 정확히 저장
        public void Register(World w, Entity e, IContext ctx)
        {
            if (ctx == null) throw new ArgumentNullException(nameof(ctx));
            BagFor(w, e)[ctx.GetType()] = ctx;
        }
        public void Register(Entity e, IContext ctx)
            => Register(_world, e, ctx);
        
        public bool Remove<T>(World w, Entity e) where T : class, IContext
        {
            if (w == null) throw new ArgumentNullException(nameof(w));
            var perEntity = BagFor(w);
            if (!perEntity.TryGetValue(e.Id, out var ctxs)) return false;
            var removed = ctxs.Remove(typeof(T));
            if (ctxs.Count == 0) perEntity.Remove(e.Id);
            return removed;
        }
        public bool Remove<T>(Entity e) where T : class, IContext
            => Remove<T>(_world, e);

        public void Clear(World w, Entity e) => BagFor(w).Remove(e.Id);
        public void Clear(Entity e) => Clear(_world, e);
        public void ClearAll() => _byWorld.Clear();

        public bool TryGet<T>(World w, Entity e, out T ctx) where T : class, IContext
        {
            if (w == null) throw new ArgumentNullException(nameof(w));
            ctx = null!;
            var perEntity = BagFor(w);
            if (perEntity.TryGetValue(e.Id, out var ctxs) &&
                ctxs.TryGetValue(typeof(T), out var obj))
            {
                ctx = obj as T;
                return ctx != null;
            }
            return false;
        }
        public bool TryGet<T>(Entity e, out T ctx) where T : class, IContext
            => TryGet(_world, e, out ctx);

        public T Get<T>(World w, Entity e) where T : class, IContext
            => TryGet<T>(w, e, out var v) ? v :
                throw new KeyNotFoundException($"Context {typeof(T).Name} not found for Entity {e}.");
        public T Get<T>(Entity e) where T : class, IContext
            => Get<T>(_world, e);

        public bool Has<T>(World w, Entity e) where T : class, IContext
            => TryGet<T>(w, e, out _);
        public bool Has<T>(Entity e) where T : class, IContext
            => Has<T>(_world, e);
    }

    internal sealed class ReferenceEqualityComparer<TRef> : IEqualityComparer<TRef> where TRef : class
    {
        public static readonly ReferenceEqualityComparer<TRef> Instance = new();
        public bool Equals(TRef x, TRef y) => ReferenceEquals(x, y);
        public int GetHashCode(TRef obj) => System.Runtime.CompilerServices.RuntimeHelpers.GetHashCode(obj);
    }
}