﻿#nullable enable

namespace ZenECS.Core.Binding
{
    public interface IContextLookup
    {
        bool TryGet<T>(World w, Entity e, out T ctx) where T : class, IContext;
        bool TryGet<T>(Entity e, out T ctx)        where T : class, IContext;
        T Get<T>(World w, Entity e) where T : class, IContext;
        T Get<T>(Entity e)          where T : class, IContext;
        bool Has<T>(World w, Entity e) where T : class, IContext;
        bool Has<T>(Entity e)          where T : class, IContext;
    }
    
    public interface IContextRegistry : IContextLookup
    {
        void Register<T>(World w, Entity e, T ctx) where T : class, IContext;
        void Register<T>(Entity e, T ctx)         where T : class, IContext;

        void Register(World w, Entity e, IContext ctx);
        void Register(Entity e, IContext ctx);
        
        bool Remove<T>(World w, Entity e) where T : class, IContext;
        bool Remove<T>(Entity e)          where T : class, IContext;

        void Clear(World w, Entity e);
        void Clear(Entity e);
        void ClearAll();
    }    
}
