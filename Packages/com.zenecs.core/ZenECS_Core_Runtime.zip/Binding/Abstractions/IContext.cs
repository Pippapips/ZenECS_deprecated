﻿#nullable enable

namespace ZenECS.Core.Binding
{
    /// <summary>Per-entity resource container marker shared across binders.</summary>
    public interface IContext { }
}