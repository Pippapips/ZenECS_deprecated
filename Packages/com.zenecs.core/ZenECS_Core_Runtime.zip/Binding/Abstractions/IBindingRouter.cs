﻿namespace ZenECS.Core.Binding
{
    public interface IBindingRouter
    {
        void Attach(Entity e, IBinder binder);
        void Detach(Entity e, IBinder binder);
        void DetachAll(Entity e);
        void OnEntityDestroyed(Entity e);
        void ApplyAll();
        void Dispatch<T>(in ComponentDelta<T> d) where T : struct;
    }
}